from items import *
from map import rooms

inventory = []
Energy = 30
Day = 6
Start_Day = 1
Team_Member = 0
Coding = 0
Talk_Once_Check_Turing = False
Talk_Once_Check_Zucc = False
turing_counter = 0
vouchercheck = False
# Start game at the reception
current_room = rooms["Home"]
